/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prova_guilhermeweis;

import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author Guilherme
 */
public class Prova_GuilhermeWeis {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner ler = new Scanner(System.in);
        LinkedList<ContaBancaria> listaConta = new LinkedList<>();

        System.out.println("DESEJA: 1 - Cadrastar conta, 2 - Visualizar contas cadrastradas, 3 - Verificar saldo, 4 - Sair");
        int opcao = ler.nextInt();
        while (opcao != 4) {
            if (opcao == 1) {
                
                System.out.println("Informe o nome: ");
                String nome = ler.nextLine();
                nome = ler.nextLine();
                System.out.println("Informe o CPF: ");
                String cpf = ler.nextLine();
                System.out.println("Informe o saldo da conta: ");
                float saldo = ler.nextFloat();

                ContaBancaria minhaConta = new ContaBancaria(nome, cpf, saldo);

                listaConta.add(minhaConta);
                System.out.println("Conta cadrastada com sucesso! ");
            } else if (opcao == 2) {
                for (int i = 0; i < listaConta.size(); i++) {
                    ContaBancaria minhaConta = listaConta.get(i);
                    System.out.println("Nome: " + minhaConta.getNomeTitular() + ", CPF: " + minhaConta.getCpfTitular() + ", Saldo: " + minhaConta.getSaldo());
                }
            } else if (opcao == 3) {
                System.out.println("Informe a posicao da conta desejada: ");
                int posicao = ler.nextInt();
                if (posicao >= 0 && posicao < listaConta.size()) {
                    ContaBancaria minhaConta = listaConta.get(posicao);
                    System.out.println("Nome: " + minhaConta.getNomeTitular() + ", CPF: " + minhaConta.getCpfTitular() + ", Saldo: " + minhaConta.getSaldo());
                } else {
                    System.out.println("Erro: posicao informada é inválida.");
                }
            }
            System.out.println("1 - Cadrastar conta, 2 - Visualizar contas cadrastradas, 3 - Verificar saldo, 4 - Sair");
            opcao = ler.nextInt();
        }
    }
}
