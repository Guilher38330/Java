/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package orientacaoobjetos3am_2023;

/**
 *
 * @author aluno
 */
public class Lampada {

    String Cor;
    String Modelo;
    float Potencia;
    int Estado;
    
     public void liga() {
        System.out.println("Você ligou a lampada!.");
    }
    
    public void desliga() {
        System.out.println("Você desligou a lampada!.");
    }
}
